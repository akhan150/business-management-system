package com.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.exception.ResourceNotFoundException;
import com.model.Employee;
import com.repository.EmployeeRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class EmployeeController {
	@Autowired
	private EmployeeRepository employeeRepository;
	
	//Get All Employees
	@GetMapping("/employees")
	public List<Employee> getAllEmployees(){
		return employeeRepository.findAll();
	}
	
	//Get Employee By ID
	@GetMapping("/employees/{id}")
	public ResponseEntity<Employee> getSpecificEmployee(@PathVariable Long id) {
		Employee specifiedEmployee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("There is no Employee with ID: " + Long.toString(id)));
		return ResponseEntity.ok(specifiedEmployee);
	}
	
	//Create a new Employee
	@PostMapping("/employees")
	public Employee createEmployee(@RequestBody Employee newEmployee) {
		return employeeRepository.save(newEmployee);
	}
	
	//Update an Employee
	@PutMapping("/employees/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee newValues) {
		Employee specifiedEmployee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("There is no Employee with ID: " + Long.toString(id)));
		specifiedEmployee.setFirstName(newValues.getFirstName());
		specifiedEmployee.setLastName(newValues.getLastName());
		specifiedEmployee.setemailAddress(newValues.getemailAddress());
		employeeRepository.save(specifiedEmployee);
		return ResponseEntity.ok(specifiedEmployee);
	}
	
	//Delete an Employee
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id) {
		Employee specifiedEmployee = employeeRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("There is no Employee with ID: " + Long.toString(id)));
		employeeRepository.delete(specifiedEmployee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
		
	}
}

